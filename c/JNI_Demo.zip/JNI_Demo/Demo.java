package jni.test; 
 
public class Demo { 

public static int COUNT = 8; 

public String msg; 
private int[] counts; 
public Demo() { 
this("ȱʡ���캯��"); 
} 

public Demo(String msg) { 
 System.out.println("<init>:" + msg); 
 this.msg = msg; 
 this.counts = null; 
} 

public String getMessage() { 
 return msg; 
} 
 
public int[] getCounts() { 
 return counts; 
} 

public void setCounts(int[] counts) { 
 this.counts = counts; 
} 

public void throwExcp() throws IllegalAccessException { 
 throw new IllegalAccessException("exception occur."); 
} 
} 